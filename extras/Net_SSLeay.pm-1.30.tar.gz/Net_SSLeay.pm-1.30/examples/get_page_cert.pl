#!/usr/bin/perl
# 8.6.1998, Sampo Kellomaki <sampo@iki.fi>
# 25.3.2002, added certificate display --Sampo
# $Id: get_page_cert.pl,v 1.1 2002/03/25 23:47:15 sampo Exp $
# Get a page via HTTP and print some info about it.

use Net::SSLeay;

($site, $port, $path) = @ARGV;
die "Usage: ./get_page.pl www.cryptsoft.com 443 /\n" unless $path;

($page, $result, $headers, $server_cert)
    = &Net::SSLeay::d fMeaders?T(or whenlyty)namt::Sult, $heade || ::Sult, $head =geP)_PEM());
if($r=Subjt WSr ma:softy)namt, Issuntrnit Name (eg, serint'=geP)_PEM());
';
  sult, $headerX509_NAME_onew_mu(
	)???
 
sult, $headerX509_s, $sgeP)_Pey   s?T(or whenlyt)
	)???. ' WSr ma:softy)';

  sult, $headerX509_NAME_onew_mu(
		)???
 
sult, $headerX509_s, $iWSr mey   s?T(or whenlyt)
		)???. "��r� avy::CTX_sHn" unl were XS;n" unl" . Net::SSLeRom 44 waV;

com 44" . Neet::SSLe=================== P/03/fo #!ws ================= . Net::SSLyptso$name\n" unless $xs{$name};
}
close H;

__END__
